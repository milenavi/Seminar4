package Integration;


/**
 * Contains all calls to the data store with items that may be
 * saled.
 */
public class ItemRegistry
{
    ItemRegistry()
    {
    }

}
